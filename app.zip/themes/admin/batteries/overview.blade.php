<div class="card" id="section-overview">
	<div
		class="card-header bg-teal-400 header-elements-inline">
		<h6 class="card-title">All Batteries</h6>
	</div>

	<div class="card-body">
		<div class="table-responsive">
			<table class="table table-bordered table-striped table-hover" id="table-batteries">
				<thead>
				<tr>
					<th>Name</th>
										<th>Status</th>

					<th>Actions</th>
				</tr>
				</thead>

			</table>
		</div>
	</div>
</div>
