<?php

namespace App\Http\Controllers;

class PointOfSale extends Controller
{
  public function index()
  {
    return view( 'admin.pos.index' );
  }
  
}
